# HFML Mini-Guide for Users

Human Frequency Markup Language (HFML) is a light-weight convention for
wrapping your requests so that AI Persona-as-a-Software™ companions can
clearly understand **what kind of help you want**.

This mini-guide focuses on a few safe, everyday task modes.

## 1. Basic pattern

Wrap your message like this:

```text
[hfml:task=<mode>]
...your message here...
[/hfml]
```

The `task` tells the persona what role to lean into.

## 2. Commonly useful modes

- `analyse` – ask the persona to break something down, explain patterns, and
  reflect on trade-offs.

  ```text
  [hfml:task=analyse]
  I keep switching productivity systems and never stick to one. What patterns
  do you see in my behaviour based on what I've told you so far?
  [/hfml]
  ```

- `plan` – structure a next step or multi-step plan.

  ```text
  [hfml:task=plan]
  Help me design a 4-week, low-stress plan to organise my finances and reduce
  my anxiety about money.
  [/hfml]
  ```

- `compare` – weigh options side by side.

  ```text
  [hfml:task=compare]
  Compare working as a freelancer vs. taking a stable full-time job for the
  next 2 years, given my need for stability and growth.
  [/hfml]
  ```

- `coach` – gentle, non-clinical coaching and accountability.

  ```text
  [hfml:task=coach]
  I want you to act as a non-therapeutic coach. Help me commit to one small
  habit to improve my sleep over the next 7 days.
  [/hfml]
  ```

- `research` – ask for structured, sourced research (within the persona's
  non-expert, non-clinical boundaries).

  ```text
  [hfml:task=research]
  Give me a high-level overview of different budgeting methods people use,
  and suggest which ones might fit a family with irregular income.
  [/hfml]
  ```

## 3. Safety and scope

- The community personas are **non-clinical** and **non-advisory**:
  - They do not replace doctors, therapists, lawyers, or financial advisors.
- HFML does not change that: it only **clarifies intent**, it does not
  override safety boundaries.
- If you push the personas outside their scope, they should refuse and
  redirect you to safer options.

For the full HFML specification and governance model, consult the official
AI Persona-as-a-Software™ Community Trilogy release.
