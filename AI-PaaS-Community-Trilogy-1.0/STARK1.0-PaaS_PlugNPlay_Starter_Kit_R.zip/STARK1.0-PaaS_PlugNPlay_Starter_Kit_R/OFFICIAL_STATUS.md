# Official Status – AI Persona-as-a-Software™ Community Starter Kit

This ZIP archive is an **official community starter kit** for a governed
persona from the AI Persona-as-a-Software™ Community Trilogy (EVA, EINY, or
STARK).

It is designed to make it trivial to install one of the community personas
into your preferred AI tools while preserving scope, safety rules, and the
Human Frequency Markup Language (HFML) interface.

---

## 1. What makes this kit "official"?

- The boot prompt in:
  - `*_BOOT_PROMPT.txt`
  matches the corresponding **community edition persona** defined in the
  AI Persona-as-a-Software™ Community Trilogy release (and, where applicable,
  its Community Master Pack).

- The kit is distributed together with:
  - A Human Frequency Markup Language (HFML) mini-guide.
  - A simple installation guide.
  - A short sharing template for social posts.
  - This official-status note.

The canonical reference for concepts, governance, and HFML is the AI
Persona-as-a-Software™ framework and Community Trilogy documentation.

---

## 2. How to verify authenticity

To check that a starter kit is likely authentic:

1. Confirm that the ZIP comes from an official publication, repository, or
   release channel associated with the AI Persona-as-a-Software™ Community
   Trilogy (for example, a DOI-linked repository or an author-controlled site).

2. Check that the internal file names include at least:

   - `*_BOOT_PROMPT.txt`
   - `HFML_MINI_GUIDE_FOR_USERS.md`
   - `INSTALL_IN_60_SECONDS.md`
   - `SHARE_THIS.md`
   - `OFFICIAL_STATUS.md`

3. For higher-assurance environments, you can also:

   - Compare the SHA-256 hash of this ZIP against a hash published in an
     official release note or repository.
   - Keep a local record of the hash you received, together with the date and
     source, for auditing.

In some distributions, you may see **three boot prompts together** (EVA, EINY,
STARK) inside a single Trilogy starter kit. In persona-specific starter kits,
you will typically see just one `*_BOOT_PROMPT.txt` file.

---

## 3. Forks, modifications, and naming

You may encounter community forks or modified versions of these personas.

- Only packs that preserve the **safety scope**, **naming conventions**, and
  **non-clinical, non-advisory boundaries**, and that are distributed through
  official or clearly endorsed channels, should be treated as canonical
  instances of EVA, EINY, or STARK.

- If a fork removes guardrails, changes the scope (for example, claims to
  provide clinical, legal, or financial advice), or reuses the names for
  purposes outside the original intent, it should **not** be considered an
  official persona.

When in doubt, defer to the official documentation and releases associated
with the AI Persona-as-a-Software™ Community Trilogy.
