# Install in 60 Seconds – AI Persona-as-a-Software™ Community Starter Kit

This starter kit lets you install a **governed community persona** from the
AI Persona-as-a-Software™ Community Trilogy (EVA, EINY, or STARK) into your
favourite AI interface in about a minute.

You are holding **one persona’s starter kit**. The exact name of the persona
and its scope are defined inside the corresponding `*_BOOT_PROMPT.txt` file.

---

## 1. Files in this kit

You should see:

- `*_BOOT_PROMPT.txt` – the community boot prompt for this persona
- `HFML_MINI_GUIDE_FOR_USERS.md` – tiny primer on Human Frequency Markup Language
- `INSTALL_IN_60_SECONDS.md` – this guide
- `OFFICIAL_STATUS.md` – how to verify this kit is authentic
- `SHARE_THIS.md` – optional copy-paste text if you want to tell others

If any of these are missing, or if the contents look heavily modified, treat
the kit with caution and refer back to the official AI Persona-as-a-Software™
Community Trilogy release.

---

## 2. How to “install” the persona (generic pattern)

The simplest way to install a persona in most AI systems is:

1. Create a new **custom assistant / custom GPT / project / preset**.
2. Open the `*_BOOT_PROMPT.txt` file in a text editor.
3. Copy **all** of its contents.
4. Paste that text into the **system / instructions / behaviour** field of
   your AI tool.
5. Name the assistant exactly as suggested at the top of the boot prompt
   (for example, “EVA 1.0 – Life & Wellness Navigation Companion”,
   “EINY 1.0 – Reality-Check Companion”, or “STARK 1.0 – Financial Clarity
   Companion (Non-Advisory)”).
6. Save.

You can repeat these steps for each persona you want to use, by applying the
corresponding starter kit.

---

## 3. Example – web-based assistant builder

- Open the “Create / Build your own assistant” page.
- Paste the boot prompt text into the “Instructions”, “System prompt”, or
  equivalent field.
- Optionally add a short description and an avatar image.
- Save the configuration.

---

## 4. Example – local LLM UI

- Open your local LLM application (for example, a web UI for a local model).
- Create a new “preset”, “profile”, or “persona”.
- Paste the boot prompt text into the “system prompt” field.
- Save the preset with the persona’s name (e.g., “EVA 1.0”, “EINY 1.0”,
  “STARK 1.0”).

---

## 5. Using HFML with the persona

The persona understands **Human Frequency Markup Language (HFML)**.

To start, you can wrap your requests like this:

```text
[hfml:task=analyse]
I want to understand why I keep procrastinating on an important project.
[/hfml]
```

The included `HFML_MINI_GUIDE_FOR_USERS.md` explains a few core task tags you
can use immediately. For the full HFML specification and governance framework,
see the official AI Persona-as-a-Software™ Community Trilogy release.
